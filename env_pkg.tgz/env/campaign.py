"""Campaign tasks — ultra-long-horizon episodes over whole proof cones.

A campaign task hands the agent a *workspace of files*: the transitive
OAI-import cone of a target module, every file verbatim EXCEPT that all
theorem/lemma proofs are excised to `sorry`. The agent must re-prove the
entire dependency cone bottom-up — hours of compositional work that
mirrors real research-library development.

Grading:
  - per-file fast tier (compile + per-stage axioms)
  - campaign-final: `#print axioms <main>` must show ONLY permitted
    axioms — transitively impossible if any stage is cheated
  - optional audit: comparator on the top-level challenge
  - statement identity on every decl via canonical headers recorded at
    generation time (headers.jsonl)

Workspace layout:
  ws/
    stage_00_<File>.lean ... stage_kk_<File>.lean   (dep order, target last)
    manifest.json          — stages, decl headers, permitted axioms

NOTE for the verifier: stage files keep their *original* imports; they are
compiled in order into a private package dir so downstream stages see the
agent's own earlier proofs — not the reference OAI oleans. This is what
makes the campaign honest: the kernel replay chain is the agent's alone.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

SORRY = "sorry -- TODO"


@dataclass
class CampaignSpec:
    task_id: str
    stages: list[dict]          # {file, module, n_sorried, headers:[{name,sig}]}
    main_theorem: str
    permitted_axioms: list[str]


def excise_proofs(src: str) -> tuple[str, list[dict]]:
    """Replace every theorem/lemma proof body with `by sorry`.
    Returns (new_src, headers). Line-oriented, same rules as mine_oai."""
    lines = src.splitlines()
    out, headers = [], []
    i, n = 0, len(lines)
    while i < n:
        line = lines[i]
        m = re.match(
            r"^(?:public\s+|private\s+|protected\s+|noncomputable\s+|scoped\s+|local\s+)*"
            r"(theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_'.]*)", line)
        if m:
            # capture decl span: until next col-0 decl/namespace/end/etc
            j = i
            span = [line]
            depth = 0
            while j + 1 < n:
                nxt = lines[j + 1]
                s2 = nxt.strip()
                if (nxt[:1] not in (" ", "\t") and s2
                        and re.match(r"^(import|namespace|section|end\b|open|"
                                     r"variable|universe|set_option|attribute|"
                                     r"initialize|#|syntax|macro|elab|notation|"
                                     r"deriving|export|run_cmd|--|/\-|@\[|"
                                     r"(?:public|private|protected|noncomputable|"
                                     r"scoped|local)\s)*(theorem|lemma|def|instance|"
                                     r"structure|class|inductive|abbrev|example|"
                                     r"axiom|opaque)\b)", nxt)):
                    break
                span.append(nxt)
                j += 1
            text = "\n".join(span)
            k = text.find(":=")
            head = text[:k].rstrip() if k >= 0 else text
            headers.append({"name": m.group(2), "sig": re.sub(r"\s+", " ", head)})
            out.append(f"{head} := by\n  {SORRY}")
            i = j + 1
        else:
            out.append(line)
            i += 1
    return "\n".join(out) + "\n", headers


def build_campaign(lean_root: Path, files: dict, target_module: str,
                   out_dir: Path, max_files: int = 12) -> CampaignSpec | None:
    """files = module -> {file, imports}; compute cone, emit sorried stages."""
    def cone(m):
        s = []
        seen = set()
        def go(x):
            if x in seen or not x.startswith("OAI.") or x not in files:
                return
            seen.add(x)
            for i in files[x]["imports"]:
                go(i)
            s.append(x)
        go(m)
        return s
    order = cone(target_module)
    if len(order) > max_files or target_module not in order:
        return None
    out_dir.mkdir(parents=True, exist_ok=True)
    stages = []
    for k, mod in enumerate(order):
        src = (lean_root / files[mod]["file"]).read_text()
        new, headers = excise_proofs(src)
        fname = f"stage_{k:02d}_" + files[mod]["file"].split("/")[-1]
        (out_dir / fname).write_text(new)
        stages.append({"file": fname, "module": mod,
                       "n_sorried": len(headers), "headers": headers})
    spec = CampaignSpec(
        task_id=f"camp_{target_module}",
        stages=stages,
        main_theorem="",   # filled by caller from challenge spec
        permitted_axioms=["propext", "Quot.sound", "Classical.choice"])
    (out_dir / "manifest.json").write_text(json.dumps({
        "task_id": spec.task_id, "stages": [
            {k: v for k, v in s.items() if k != "headers"} for s in stages],
        "permitted_axioms": spec.permitted_axioms}, indent=2))
    (out_dir / "headers.jsonl").write_text(
        "\n".join(json.dumps({"stage": i, **h})
                  for i, s in enumerate(stages) for h in s["headers"]))
    return spec
